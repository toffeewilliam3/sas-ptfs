import type { Express } from "express";
import type { Server } from "http";
import { storage } from "./storage";
import { api, errorSchemas } from "@shared/routes";
import { z } from "zod";
import { setupBot } from "./bot";

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  
  setupBot().catch(console.error);

  app.get(api.aircraft.list.path, async (req, res) => {
    const data = await storage.getAircraft();
    res.json(data);
  });

  app.post(api.aircraft.create.path, async (req, res) => {
    const input = api.aircraft.create.input.parse(req.body);
    const row = await storage.createAircraft(input);
    res.status(201).json(row);
  });

  app.get(api.flights.list.path, async (req, res) => {
    const flights = await storage.getFlights();
    res.json(flights);
  });

  app.post(api.flights.create.path, async (req, res) => {
    const input = api.flights.create.input.parse(req.body);
    const flight = await storage.createFlight(input);
    res.status(201).json(flight);
  });

  app.delete(api.flights.delete.path, async (req, res) => {
    await storage.deleteFlight(parseInt(req.params.id));
    res.sendStatus(204);
  });

  app.get(api.bookings.list.path, async (req, res) => {
    const bookings = await storage.getAllBookings();
    res.json(bookings);
  });

  app.post(api.bookings.approve.path, async (req, res) => {
    const id = parseInt(req.params.id);
    const { comment } = req.body;
    const booking = await storage.getBooking(id);
    if (!booking) return res.status(404).json({ message: "Not found" });

    const updated = await storage.updateBookingStatus(id, 'approved', undefined, comment);
    const user = await storage.getUser(booking.userId);
    if (user) {
      const newXp = user.xp + 100;
      const newLevel = Math.floor(newXp / 1000) + 1;
      await storage.updateUserStats(user.id, { xp: newXp, level: newLevel });
    }
    res.json(updated);
  });

  app.post(api.bookings.reject.path, async (req, res) => {
    const id = parseInt(req.params.id);
    const { comment } = req.body;
    const updated = await storage.updateBookingStatus(id, 'rejected', undefined, comment);
    res.json(updated);
  });

  app.get(api.users.list.path, async (req, res) => {
    const users = await storage.getAllUsers();
    res.json(users);
  });

  app.post(api.users.updateStats.path, async (req, res) => {
    const id = parseInt(req.params.id);
    const input = api.users.updateStats.input.parse(req.body);
    const user = await storage.updateUserStats(id, input);
    
    // Check if we need to send a DM notification for XP update
    if (req.body.dmNotify && input.xp !== undefined) {
      try {
        const { sendUserDM } = await import("./bot");
        await sendUserDM(user.discordId, `An admin has manually adjusted your stats! Your current XP is now ${user.xp} (Level ${user.level}).`);
      } catch (e) {
        console.error("Failed to send DM notification", e);
      }
    }
    res.json(user);
  });

  app.delete("/api/users/:id/bookings", async (req, res) => {
    const id = parseInt(req.params.id);
    await storage.clearUserBookings(id);
    res.sendStatus(204);
  });

  app.post(api.users.makeMeAdmin.path, async (req, res) => {
    const { discordId } = req.body;
    const success = await storage.makeUserAdmin(discordId);
    if (!success) return res.status(404).json({ message: "User not found" });
    res.json({ success: true });
  });

  // --- ROUTE CONFIGURATION ---
  // Add or remove routes from this array.
  // The system will automatically ensure these exist on startup.
  const routeDefinitions = [
    {
      flightNumber: "SAS101",
      departure: "Tokyo",
      arrival: "Perth",
      durationMinutes: 10,
      isMandatory: true,
      aircraftModel: "a320"
    },
    {
      flightNumber: "SAS202",
      departure: "Tokyo",
      arrival: "Greater Rockford",
      durationMinutes: 15,
      isMandatory: true,
      aircraftModel: "a320"
    },
    {
      flightNumber: "SAS303",
      departure: "Tokyo",
      arrival: "Izolirani",
      durationMinutes: 25,
      isMandatory: true,
      aircraftModel: "a330"
    },
    {
      flightNumber: "SAS404",
      departure: "Perth",
      arrival: "Tokyo",
      durationMinutes: 10,
      isMandatory: true,
      aircraftModel: "a340"
    }
  ];

  // Seed Data
  const existingAircraft = await storage.getAircraft();
  if (existingAircraft.length === 0) {
    await storage.createAircraft({ model: "a320", displayName: "Airbus A320" });
    await storage.createAircraft({ model: "a330", displayName: "Airbus A330" });
    await storage.createAircraft({ model: "a340", displayName: "Airbus A340" });
  }

  const updatedAircraft = await storage.getAircraft();
  const existingFlights = await storage.getFlights();
  
  if (existingFlights.length === 0) {
    for (const def of routeDefinitions) {
      const ac = updatedAircraft.find(a => a.model === def.aircraftModel);
      if (ac) {
        await storage.createFlight({
          flightNumber: def.flightNumber,
          airline: "SAS",
          departure: def.departure,
          arrival: def.arrival,
          durationMinutes: def.durationMinutes,
          isMandatory: def.isMandatory,
          aircraftId: ac.id
        });
      }
    }
  }

  return httpServer;
}
