import { Client, GatewayIntentBits, Partials, REST, Routes, SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, StringSelectMenuBuilder, MessageFlags, ModalBuilder, TextInputBuilder, TextInputStyle, InteractionType } from "discord.js";
import { storage } from "./storage";
import cron from "node-cron";

export let discordClient: Client | null = null;

export async function setupBot() {
  if (!process.env.DISCORD_TOKEN) {
    console.log("No DISCORD_TOKEN found, skipping bot setup");
    return;
  }

  const client = new Client({
    intents: [
      GatewayIntentBits.Guilds,
      GatewayIntentBits.GuildMessages,
      GatewayIntentBits.DirectMessages,
      GatewayIntentBits.MessageContent,
    ],
    partials: [Partials.Channel]
  });

  discordClient = client;

  const commands = [
    new SlashCommandBuilder()
      .setName('book')
      .setDescription('Book a flight')
      .addStringOption(option => 
        option.setName('flight')
          .setDescription('The flight number to book')
          .setRequired(true)),
    new SlashCommandBuilder()
      .setName('start')
      .setDescription('Start your booked flight timer'),
    new SlashCommandBuilder()
      .setName('flights')
      .setDescription('List available flights'),
    new SlashCommandBuilder()
      .setName('finish')
      .setDescription('Complete your journey and submit proof'),
    new SlashCommandBuilder()
      .setName('createadmin')
      .setDescription('Grant admin permissions to a user')
      .addUserOption(option => 
        option.setName('user')
          .setDescription('The user to make admin')
          .setRequired(true)),
    new SlashCommandBuilder()
      .setName('admin')
      .setDescription('Open the admin control panel'),
    new SlashCommandBuilder()
      .setName('level')
      .setDescription('Check your current level and XP')
  ];

  // Automated reminders for mandatory flights
  cron.schedule('0 12 * * *', async () => {
    if (!discordClient) return;
    const allUsers = await storage.getAllUsers();
    const mandatoryFlights = (await storage.getFlights()).filter(f => f.isMandatory);
    
    if (mandatoryFlights.length === 0) return;

    for (const user of allUsers) {
      try {
        const bookings = await storage.getAllBookings();
        const userCompletedMandatory = bookings.some(b => 
          b.userId === user.id && 
          b.status === 'approved' && 
          mandatoryFlights.some(mf => mf.id === b.flightId)
        );

        if (!userCompletedMandatory) {
          const discordUser = await discordClient.users.fetch(user.discordId);
          
          const embed = new EmbedBuilder()
            .setTitle('Mandatory Flight Reminder')
            .setDescription(`Hello ${user.username}! You have mandatory flights to complete.`)
            .setColor(0xFF0000);

          const row = new ActionRowBuilder<ButtonBuilder>()
            .addComponents(
              new ButtonBuilder()
                .setCustomId('mandatory_start')
                .setLabel('Start')
                .setStyle(ButtonStyle.Success),
              new ButtonBuilder()
                .setCustomId('mandatory_skip')
                .setLabel("Can't do it")
                .setStyle(ButtonStyle.Danger),
            );

          await discordUser.send({ embeds: [embed], components: [row] });
        }
      } catch (error) {
        // Silently fail for reminders
      }
    }
  });

  client.once('clientReady', async () => {
    console.log(`Logged in as ${client.user?.tag}!`);
    
    const rest = new REST({ version: '10' }).setToken(process.env.DISCORD_TOKEN!);
    try {
      if (client.user) {
        await rest.put(
          Routes.applicationCommands(client.user.id),
          { body: commands },
        );
        console.log('Successfully reloaded application (/) commands.');
      }
    } catch (error) {
      console.error(error);
    }
  });

  client.on('interactionCreate', async interaction => {
    // Handle Modals
    if (interaction.type === InteractionType.ModalSubmit) {
      if (interaction.customId === 'skip_reason_modal') {
        const reason = interaction.fields.getTextInputValue('reason_input');
        const user = await storage.getUserByDiscordId(interaction.user.id);
        if (user) {
          const mandatoryFlights = (await storage.getFlights()).filter(f => f.isMandatory);
          if (mandatoryFlights.length > 0) {
            const randomFlight = mandatoryFlights[Math.floor(Math.random() * mandatoryFlights.length)];
            await storage.createBooking({
              userId: user.id,
              flightId: randomFlight.id,
              status: 'skipped',
              skipReason: reason,
              startTime: null,
              endTime: null,
              proofUrl: null,
              adminComment: null
            });
            await interaction.reply({ content: 'Your reason has been recorded. An admin will review it.', flags: [MessageFlags.Ephemeral] });
          }
        }
      }
      return;
    }

    if (interaction.isButton()) {
      const user = await storage.getUserByDiscordId(interaction.user.id);
      
      // Handle Mandatory Flight Buttons
      if (interaction.customId === 'mandatory_start') {
        if (!user) {
           await interaction.reply({ content: 'User profile not found. Please use a command first.', flags: [MessageFlags.Ephemeral] });
           return;
        }
        const mandatoryFlights = (await storage.getFlights()).filter(f => f.isMandatory);
        if (mandatoryFlights.length === 0) {
          await interaction.reply({ content: 'No mandatory flights available right now.', flags: [MessageFlags.Ephemeral] });
          return;
        }

        const embed = new EmbedBuilder()
          .setTitle('Choose Mandatory Flight')
          .setDescription('Select a mandatory flight path to begin:')
          .setColor(0x0099FF);

        const select = new StringSelectMenuBuilder()
          .setCustomId('mandatory_flight_select')
          .setPlaceholder('Select a flight...')
          .addOptions(
            mandatoryFlights.slice(0, 25).map(f => ({
              label: `${f.flightNumber}: ${f.departure} -> ${f.arrival}`,
              description: `Duration: ${f.durationMinutes}m`,
              value: f.id.toString(),
            }))
          );

        const row = new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(select);
        await interaction.reply({ embeds: [embed], components: [row], flags: [MessageFlags.Ephemeral] });
        return;
      }

      if (interaction.customId === 'mandatory_skip') {
        const modal = new ModalBuilder()
          .setCustomId('skip_reason_modal')
          .setTitle('Why can\'t you fly?');

        const reasonInput = new TextInputBuilder()
          .setCustomId('reason_input')
          .setLabel("Reason for skipping")
          .setStyle(TextInputStyle.Paragraph)
          .setPlaceholder("Please explain why you cannot complete this flight...")
          .setRequired(true);

        const firstActionRow = new ActionRowBuilder<TextInputBuilder>().addComponents(reasonInput);
        modal.addComponents(firstActionRow);

        await interaction.showModal(modal);
        return;
      }

      if (!user?.isAdmin) {
        await interaction.reply({ content: 'You are not an admin.', flags: [MessageFlags.Ephemeral] });
        return;
      }

      const [action, ...args] = interaction.customId.split('_');
      
      if (action === 'admin') {
        const adminAction = args[0];
        
        if (adminAction === 'approvals') {
          const pending = await storage.getPendingBookings();
          if (pending.length === 0) {
            await interaction.reply({ content: 'No pending approval requests.', flags: [MessageFlags.Ephemeral] });
            return;
          }

          const embed = new EmbedBuilder()
            .setTitle('Pending Flight Approvals')
            .setDescription(`There are ${pending.length} pending requests to review.`)
            .setColor(0xFFAA00);

          const current = pending.slice(0, 5);
          const rows = current.map((p, i) => {
            const row = new ActionRowBuilder<ButtonBuilder>()
              .addComponents(
                new ButtonBuilder()
                  .setCustomId(`approve_${p.id}`)
                  .setLabel(`Approve ${p.user.username} (${p.flight.flightNumber})`)
                  .setStyle(ButtonStyle.Success),
                new ButtonBuilder()
                  .setCustomId(`reject_${p.id}`)
                  .setLabel(`Reject`)
                  .setStyle(ButtonStyle.Danger),
              );
            
            embed.addFields({ 
              name: `${i + 1}. ${p.user.username}`, 
              value: `Flight: ${p.flight.flightNumber}\nRoute: ${p.flight.departure} -> ${p.flight.arrival}\n[View Proof](${p.proofUrl})` 
            });
            
            return row;
          });

          await interaction.reply({ embeds: [embed], components: rows, ephemeral: true });
          return;
        }

        if (adminAction === 'mandatory') {
          const allUsers = await storage.getAllUsers();
          const mandatoryFlights = (await storage.getFlights()).filter(f => f.isMandatory);
          const allBookings = await storage.getAllBookings();

          const doing = allUsers.filter(u => allBookings.some(b => b.userId === u.id && (b.status === 'booked' || b.status === 'flying') && mandatoryFlights.some(mf => mf.id === b.flightId)));
          const skipped = allUsers.filter(u => allBookings.some(b => b.userId === u.id && b.status === 'skipped' && mandatoryFlights.some(mf => mf.id === b.flightId)));
          const done = allUsers.filter(u => allBookings.some(b => b.userId === u.id && b.status === 'approved' && mandatoryFlights.some(mf => mf.id === b.flightId)));
          const notStarted = allUsers.filter(u => !allBookings.some(b => b.userId === u.id && mandatoryFlights.some(mf => mf.id === b.flightId)));

          const embed = new EmbedBuilder()
            .setTitle('Mandatory Flight Status')
            .setColor(0x0099FF)
            .addFields(
              { name: '✅ Completed', value: done.map(u => u.username).join(', ') || 'None', inline: false },
              { name: '⏳ In Progress', value: doing.map(u => u.username).join(', ') || 'None', inline: false },
              { name: '⏭️ Skipped', value: skipped.map(u => u.username).join(', ') || 'None', inline: false },
              { name: '❌ Not Started', value: notStarted.map(u => u.username).join(', ') || 'None', inline: false }
            );

          await interaction.reply({ embeds: [embed], flags: [MessageFlags.Ephemeral] });
          return;
        }

        const users = await storage.getAllUsers();
        if (users.length === 0) {
          await interaction.reply({ content: 'No pilots found in database.', flags: [MessageFlags.Ephemeral] });
          return;
        }

        const embed = new EmbedBuilder()
          .setTitle(`${adminAction.charAt(0).toUpperCase() + adminAction.slice(1)} Action`)
          .setDescription(`Select a pilot to ${adminAction}:`)
          .setColor(0x0099FF);

        const select = new StringSelectMenuBuilder()
          .setCustomId(`admin_user_select_${adminAction}`)
          .setPlaceholder('Select a pilot...')
          .addOptions(
            users.slice(0, 25).map(u => ({
              label: u.username,
              description: `Level ${u.level}`,
              value: u.id.toString(),
            }))
          );

        const row = new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(select);
        await interaction.reply({ embeds: [embed], components: [row], flags: [MessageFlags.Ephemeral] });
        return;
      }

      if (action === 'approve') {
        const bookingIdStr = args[0];
        const bookingId = parseInt(bookingIdStr);
        const booking = await storage.getBooking(bookingId);
        if (booking) {
          await storage.updateBookingStatus(bookingId, 'approved');
          const u = await storage.getUser(booking.userId);
          if (u) {
            const newXp = u.xp + 100;
            const newLevel = Math.floor(newXp / 1000) + 1;
            await storage.updateUserStats(u.id, { xp: newXp, level: newLevel });
            
            try {
              const discordUser = await client.users.fetch(u.discordId);
              await discordUser.send(`Your flight ${bookingId} has been approved! +100 XP`);
            } catch (e) {}
          }
          await interaction.update({ content: `✅ Approved flight request for ${bookingId}`, embeds: [], components: [] });
        }
      } else if (action === 'reject') {
        const bookingIdStr = args[0];
        const bookingId = parseInt(bookingIdStr);
        await storage.updateBookingStatus(bookingId, 'rejected');
        await interaction.update({ content: `❌ Rejected flight request for ${bookingId}`, embeds: [], components: [] });
      }
      return;
    }

    if (interaction.isStringSelectMenu()) {
      if (interaction.customId === 'mandatory_flight_select') {
        const flightId = parseInt(interaction.values[0]);
        const user = await storage.getUserByDiscordId(interaction.user.id);
        if (user) {
          const activeBooking = await storage.getUserActiveBooking(user.id);
          if (activeBooking) {
            await interaction.reply({ content: 'You already have an active booking!', flags: [MessageFlags.Ephemeral] });
            return;
          }

          await storage.createBooking({
            userId: user.id,
            flightId: flightId,
            status: 'booked',
            startTime: null,
            endTime: null,
            proofUrl: null,
            adminComment: null,
            skipReason: null
          });

          await interaction.reply({ content: `Successfully booked mandatory flight! Use /start when you are ready to fly.`, flags: [MessageFlags.Ephemeral] });
        }
        return;
      }

      const user = await storage.getUserByDiscordId(interaction.user.id);
      if (!user?.isAdmin) {
        await interaction.reply({ content: 'You are not an admin.', flags: [MessageFlags.Ephemeral] });
        return;
      }

      if (interaction.customId.startsWith('admin_user_select_')) {
        const adminAction = interaction.customId.split('_')[3];
        const userId = parseInt(interaction.values[0]);
        const targetDbUser = await storage.getUser(userId);

        if (!targetDbUser) {
          await interaction.reply({ content: 'Pilot not found.', flags: [MessageFlags.Ephemeral] });
          return;
        }

        if (adminAction === 'warn') {
          await storage.updateUserStats(userId, { warnings: (targetDbUser.warnings || 0) + 1 });
          await interaction.reply({ content: `✅ Issued warning to ${targetDbUser.username}. Total warnings: ${(targetDbUser.warnings || 0) + 1}`, flags: [MessageFlags.Ephemeral] });
        } else if (adminAction === 'cancel') {
          await storage.clearUserBookings(userId);
          await interaction.reply({ content: `✅ Cleared all active flight plans for ${targetDbUser.username}.`, flags: [MessageFlags.Ephemeral] });
        } else if (adminAction === 'level') {
          const xpToAdd = 500; 
          const newXp = targetDbUser.xp + xpToAdd;
          const newLevel = Math.floor(newXp / 1000) + 1;
          await storage.updateUserStats(userId, { xp: newXp, level: newLevel });
          await interaction.reply({ content: `✅ Added ${xpToAdd} XP to ${targetDbUser.username}. New Level: ${newLevel}`, flags: [MessageFlags.Ephemeral] });
          try {
            const discordUser = await client.users.fetch(targetDbUser.discordId);
            await discordUser.send(`An admin has manually adjusted your stats! Your current XP is now ${newXp} (Level ${newLevel}).`);
          } catch (e) {}
        }
        return;
      }
    }

    if (!interaction.isChatInputCommand()) return;

    let user = await storage.getUserByDiscordId(interaction.user.id);
    if (!user) {
      user = await storage.createUser({
        discordId: interaction.user.id,
        username: interaction.user.username,
        level: 1,
        xp: 0,
        isAdmin: false
      });
    }

    if (interaction.commandName === 'createadmin') {
      if (!user.isAdmin) {
        await interaction.reply({ content: 'Only admins can use this command.', flags: [MessageFlags.Ephemeral] });
        return;
      }
      const targetUser = interaction.options.getUser('user');
      if (targetUser) {
        await storage.makeUserAdmin(targetUser.id);
        await interaction.reply({ content: `Successfully made ${targetUser.username} an admin!`, flags: [MessageFlags.Ephemeral] });
      }
    }

    if (interaction.commandName === 'admin') {
      if (!user.isAdmin) {
        await interaction.reply({ content: 'You do not have permission to use this command.', flags: [MessageFlags.Ephemeral] });
        return;
      }

      const embed = new EmbedBuilder()
        .setTitle('Admin Control Panel')
        .setDescription('Select an administrative action below:')
        .setColor(0x0099FF);

      const row = new ActionRowBuilder<ButtonBuilder>()
        .addComponents(
          new ButtonBuilder()
            .setCustomId('admin_warn')
            .setLabel('Warn Pilot')
            .setStyle(ButtonStyle.Secondary),
          new ButtonBuilder()
            .setCustomId('admin_level')
            .setLabel('Adjust Level/XP')
            .setStyle(ButtonStyle.Secondary),
          new ButtonBuilder()
            .setCustomId('admin_approvals')
            .setLabel('Approvals')
            .setStyle(ButtonStyle.Primary),
          new ButtonBuilder()
            .setCustomId('admin_cancel')
            .setLabel('Cancel Flight Plans')
            .setStyle(ButtonStyle.Danger),
          new ButtonBuilder()
            .setCustomId('admin_mandatory')
            .setLabel('Mandatory Status')
            .setStyle(ButtonStyle.Secondary),
        );

      await interaction.reply({ embeds: [embed], components: [row], flags: [MessageFlags.Ephemeral] });
    }

    if (interaction.commandName === 'level') {
      const embed = new EmbedBuilder()
        .setTitle(`${interaction.user.username}'s Progress`)
        .setColor(0x0099FF)
        .addFields(
          { name: 'Level', value: user.level.toString(), inline: true },
          { name: 'XP', value: user.xp.toString(), inline: true },
          { name: 'Warnings', value: (user.warnings || 0).toString(), inline: true }
        )
        .setThumbnail(interaction.user.displayAvatarURL());

      await interaction.reply({ embeds: [embed], flags: [MessageFlags.Ephemeral] });
    }

    if (interaction.commandName === 'flights') {
      const flights = await storage.getFlights();
      const embed = new EmbedBuilder()
        .setTitle('Available Flights')
        .setColor(0x0099FF);
      
      const flightList = flights.map(f => `**${f.flightNumber}**: ${f.airline} - ${f.departure} to ${f.arrival} (${f.aircraft?.displayName || 'Any'})\n*Duration: ${f.durationMinutes}m*${f.isMandatory ? ' [MANDATORY]' : ''}`).join('\n\n');
      
      embed.setDescription(flightList || 'No flights available.');
      await interaction.reply({ embeds: [embed], flags: [MessageFlags.Ephemeral] });
    }

    if (interaction.commandName === 'book') {
      const flightNumber = interaction.options.getString('flight');
      const flight = await storage.getFlightByNumber(flightNumber || '');
      
      if (!flight) {
        await interaction.reply({ content: 'Flight not found!', flags: [MessageFlags.Ephemeral] });
        return;
      }

      const activeBooking = await storage.getUserActiveBooking(user.id);
      if (activeBooking) {
        await interaction.reply({ content: 'You already have an active booking!', flags: [MessageFlags.Ephemeral] });
        return;
      }

      await storage.createBooking({
        userId: user.id,
        flightId: flight.id,
        status: 'booked',
        startTime: null,
        endTime: null,
        proofUrl: null,
        adminComment: null,
        skipReason: null
      });

      await interaction.reply({ content: `Successfully booked flight ${flight.flightNumber}! Use /start when you are ready to fly.`, flags: [MessageFlags.Ephemeral] });
    }

    if (interaction.commandName === 'start') {
      const booking = await storage.getUserActiveBooking(user.id);
      if (!booking || (booking.status !== 'booked' && booking.status !== 'skipped')) {
        await interaction.reply({ content: 'You have no booked flight to start.', flags: [MessageFlags.Ephemeral] });
        return;
      }

      await storage.updateBookingStatus(booking.id, 'flying');
      
      try {
        const u = await client.users.fetch(interaction.user.id);
        const embed = new EmbedBuilder()
          .setTitle('Flight Started!')
          .setDescription('Your flight has been booked and started. Please use `/finish` once you have completed your journey to submit your proof.')
          .setColor(0x0099FF);
        
        await u.send({ embeds: [embed] });
      } catch (e) {
        console.error("Failed to send start DM", e);
      }

      await interaction.reply({ content: `Flight started! Check your DMs for instructions.`, flags: [MessageFlags.Ephemeral] });
    }

    if (interaction.commandName === 'finish') {
      const booking = await storage.getUserActiveBooking(user.id);
      if (!booking || booking.status !== 'flying') {
        await interaction.reply({ content: 'You do not have an active flight in progress. Use `/start` first.', flags: [MessageFlags.Ephemeral] });
        return;
      }

      const embed = new EmbedBuilder()
        .setTitle('Complete Your Journey')
        .setDescription('Please upload a screenshot of your flight stats here in DMs to complete your booking and submit it for review.')
        .setColor(0x00FF00);

      try {
        const u = await client.users.fetch(interaction.user.id);
        await u.send({ embeds: [embed] });
        await interaction.reply({ content: 'Instructions sent to your DMs!', flags: [MessageFlags.Ephemeral] });
      } catch (e) {
        await interaction.reply({ content: 'I couldn\'t send you a DM. Please make sure your DMs are open.', flags: [MessageFlags.Ephemeral] });
      }
    }
  });

  client.on('messageCreate', async message => {
    if (message.author.bot) return;
    if (message.guild) return;

    const user = await storage.getUserByDiscordId(message.author.id);
    if (!user) return;

    const booking = await storage.getUserActiveBooking(user.id);
    if (booking && booking.status === 'flying') {
      const attachment = message.attachments.first();
      if (attachment) {
        await storage.updateBookingStatus(booking.id, 'submitted', attachment.url);
        await message.reply("Proof received! An admin will review it shortly.");
      } else {
        await message.reply("Please send an image attachment as proof.");
      }
    }
  });

  try {
    await client.login(process.env.DISCORD_TOKEN);
  } catch (e) {
    console.error("Failed to login to Discord", e);
  }
}

export async function sendUserDM(discordId: string, message: string) {
  if (!discordClient) return;
  try {
    const user = await discordClient.users.fetch(discordId);
    await user.send(message);
  } catch (e) {
    console.error(`Failed to send DM to ${discordId}`, e);
  }
}
