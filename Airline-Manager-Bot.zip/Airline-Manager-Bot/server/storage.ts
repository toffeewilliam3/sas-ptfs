import { db } from "./db";
import {
  users, flights, bookings, aircraft,
  type User, type InsertUser,
  type Flight, type InsertFlight,
  type Booking, type InsertBooking,
  type Aircraft, type InsertAircraft
} from "@shared/schema";
import { eq, desc, and, or } from "drizzle-orm";

export interface IStorage {
  // Users
  getUser(id: number): Promise<User | undefined>;
  getUserByDiscordId(discordId: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUserStats(id: number, stats: { level?: number; xp?: number; warnings?: number }): Promise<User>;
  getAllUsers(): Promise<User[]>;
  makeUserAdmin(discordId: string): Promise<boolean>;
  deleteFlight(id: number): Promise<void>;
  clearUserBookings(userId: number): Promise<void>;

  // Aircraft

  // Bookings
  createBooking(booking: InsertBooking): Promise<Booking>;
  getBooking(id: number): Promise<Booking | undefined>;
  getUserActiveBooking(userId: number): Promise<Booking | undefined>;
  updateBookingStatus(id: number, status: string, proofUrl?: string, adminComment?: string): Promise<Booking>;
  getAllBookings(): Promise<(Booking & { user: User; flight: Flight })[]>;
  getPendingBookings(): Promise<(Booking & { user: User; flight: Flight })[]>;
}

export class DatabaseStorage implements IStorage {
  // Users
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByDiscordId(discordId: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.discordId, discordId));
    return user;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db.insert(users).values(insertUser).returning();
    return user;
  }

  async updateUserStats(id: number, stats: { level?: number; xp?: number; warnings?: number }): Promise<User> {
    const updates: any = {};
    if (stats.level !== undefined) updates.level = stats.level;
    if (stats.xp !== undefined) updates.xp = stats.xp;
    if (stats.warnings !== undefined) updates.warnings = stats.warnings;

    const [user] = await db.update(users)
      .set(updates)
      .where(eq(users.id, id))
      .returning();
    return user;
  }

  async getAllUsers(): Promise<User[]> {
    return await db.select().from(users).orderBy(desc(users.level));
  }

  async makeUserAdmin(discordId: string): Promise<boolean> {
    const [user] = await db.update(users)
      .set({ isAdmin: true })
      .where(eq(users.discordId, discordId))
      .returning();
    return !!user;
  }

  async deleteFlight(id: number): Promise<void> {
    await db.delete(flights).where(eq(flights.id, id));
  }

  async clearUserBookings(userId: number): Promise<void> {
    await db.delete(bookings).where(
      and(
        eq(bookings.userId, userId),
        or(eq(bookings.status, 'booked'), eq(bookings.status, 'flying'))
      )
    );
  }

  // Aircraft
  async createAircraft(data: InsertAircraft): Promise<Aircraft> {
    const [item] = await db.insert(aircraft).values(data).returning();
    return item;
  }

  async getAircraft(): Promise<Aircraft[]> {
    return await db.select().from(aircraft);
  }

  // Flights
  async getFlights(): Promise<(Flight & { aircraft: Aircraft | null })[]> {
    return await db.query.flights.findMany({
      with: {
        aircraft: true
      }
    });
  }

  async getFlight(id: number): Promise<Flight | undefined> {
    const [flight] = await db.select().from(flights).where(eq(flights.id, id));
    return flight;
  }

  async getFlightByNumber(flightNumber: string): Promise<Flight | undefined> {
    const [flight] = await db.select().from(flights).where(eq(flights.flightNumber, flightNumber));
    return flight;
  }

  async createFlight(insertFlight: InsertFlight): Promise<Flight> {
    const [flight] = await db.insert(flights).values(insertFlight).returning();
    return flight;
  }

  // Bookings
  async createBooking(insertBooking: InsertBooking): Promise<Booking> {
    const [booking] = await db.insert(bookings).values(insertBooking).returning();
    return booking;
  }

  async getBooking(id: number): Promise<Booking | undefined> {
    const [booking] = await db.select().from(bookings).where(eq(bookings.id, id));
    return booking;
  }

  async getUserActiveBooking(userId: number): Promise<Booking | undefined> {
    const [booking] = await db.select().from(bookings)
      .where(
        and(
          eq(bookings.userId, userId),
          or(eq(bookings.status, 'booked'), eq(bookings.status, 'flying'))
        )
      )
      .orderBy(desc(bookings.id))
      .limit(1);
    
    return booking;
  }

  async updateBookingStatus(id: number, status: string, proofUrl?: string, adminComment?: string): Promise<Booking> {
    const updates: any = { status };
    if (proofUrl) updates.proofUrl = proofUrl;
    if (adminComment) updates.adminComment = adminComment;
    if (status === 'flying' && !proofUrl) updates.startTime = new Date();
    if (status === 'submitted') updates.endTime = new Date();

    const [booking] = await db.update(bookings)
      .set(updates)
      .where(eq(bookings.id, id))
      .returning();
    return booking;
  }

  async getAllBookings(): Promise<(Booking & { user: User; flight: Flight })[]> {
    return await db.query.bookings.findMany({
      with: {
        user: true,
        flight: true
      },
      orderBy: desc(bookings.createdAt)
    });
  }

  async getPendingBookings(): Promise<(Booking & { user: User; flight: Flight })[]> {
    return await db.query.bookings.findMany({
      where: eq(bookings.status, 'submitted'),
      with: {
        user: true,
        flight: true
      }
    });
  }
}

export const storage = new DatabaseStorage();
