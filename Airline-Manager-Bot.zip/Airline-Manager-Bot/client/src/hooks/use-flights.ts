import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api, type InsertFlight } from "@shared/routes";
import { useToast } from "@/hooks/use-toast";

export function useFlights() {
  return useQuery({
    queryKey: [api.flights.list.path],
    queryFn: async () => {
      const res = await fetch(api.flights.list.path);
      if (!res.ok) throw new Error("Failed to fetch flights");
      return api.flights.list.responses[200].parse(await res.json());
    },
  });
}

export function useCreateFlight() {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: async (data: InsertFlight) => {
      // Coerce number types for form data safety
      const payload = {
        ...data,
        durationMinutes: Number(data.durationMinutes),
      };
      
      const validated = api.flights.create.input.parse(payload);
      
      const res = await fetch(api.flights.create.path, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(validated),
      });

      if (!res.ok) {
        if (res.status === 400) {
          const error = api.flights.create.responses[400].parse(await res.json());
          throw new Error(error.message);
        }
        throw new Error("Failed to create flight");
      }
      return api.flights.create.responses[201].parse(await res.json());
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.flights.list.path] });
      toast({
        title: "Flight Created",
        description: "The flight route has been successfully added to the system.",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    }
  });
}
