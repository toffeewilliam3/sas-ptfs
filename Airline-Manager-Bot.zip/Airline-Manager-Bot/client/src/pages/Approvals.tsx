import { useBookings, useApproveBooking, useRejectBooking } from "@/hooks/use-bookings";
import { Check, X, Eye, Clock, Calendar, AlertCircle, CheckSquare } from "lucide-react";
import { useState } from "react";
import { format } from "date-fns";
import { motion, AnimatePresence } from "framer-motion";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";

export default function Approvals() {
  const { data: bookings, isLoading } = useBookings();
  const { mutate: approve, isPending: isApproving } = useApproveBooking();
  const { mutate: reject, isPending: isRejecting } = useRejectBooking();
  
  const [selectedBookingId, setSelectedBookingId] = useState<number | null>(null);
  const [selectedProof, setSelectedProof] = useState<string | null>(null);

  if (isLoading) return <div className="p-8 text-center text-slate-500">Loading requests...</div>;

  const pendingRequests = (bookings || []).filter(b => b.status === 'submitted');
  const selectedBooking = pendingRequests.find(b => b.id === selectedBookingId);

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl font-display font-bold text-slate-900">Approval Requests</h1>
        <p className="text-slate-500 mt-2">Manage and review pending flight submissions.</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-1 space-y-4">
          <Card className="border-slate-100 shadow-sm overflow-hidden">
            <CardHeader className="bg-slate-50/50 border-b border-slate-100 py-4">
              <div className="flex items-center justify-between">
                <CardTitle className="text-sm font-semibold text-slate-700">Pending List</CardTitle>
                <Badge variant="secondary" className="bg-blue-50 text-blue-600 border-blue-100">
                  {pendingRequests.length}
                </Badge>
              </div>
            </CardHeader>
            <CardContent className="p-0">
              <ScrollArea className="h-[calc(100vh-300px)]">
                {pendingRequests.length === 0 ? (
                  <div className="p-8 text-center">
                    <Check className="w-8 h-8 text-green-400 mx-auto mb-2 opacity-50" />
                    <p className="text-sm text-slate-500">All caught up!</p>
                  </div>
                ) : (
                  <div className="divide-y divide-slate-50">
                    {pendingRequests.map((request) => (
                      <button
                        key={request.id}
                        onClick={() => setSelectedBookingId(request.id)}
                        className={cn(
                          "w-full text-left p-4 transition-all hover:bg-slate-50 flex items-start gap-3",
                          selectedBookingId === request.id ? "bg-blue-50/50 border-l-4 border-blue-500" : "border-l-4 border-transparent"
                        )}
                        data-testid={`button-select-request-${request.id}`}
                      >
                        <div className="h-8 w-8 rounded-full bg-blue-100 flex items-center justify-center text-blue-600 font-bold text-xs shrink-0">
                          {request.user.username.substring(0, 2).toUpperCase()}
                        </div>
                        <div className="min-w-0">
                          <p className="text-sm font-semibold text-slate-900 truncate">{request.user.username}</p>
                          <p className="text-xs text-slate-500 font-medium">{request.flight.flightNumber} • {request.flight.departure} → {request.flight.arrival}</p>
                          <p className="text-[10px] text-slate-400 mt-1 uppercase tracking-wider">{format(new Date(request.createdAt!), 'MMM d, HH:mm')}</p>
                        </div>
                      </button>
                    ))}
                  </div>
                )}
              </ScrollArea>
            </CardContent>
          </Card>
        </div>

        <div className="lg:col-span-2">
          <AnimatePresence mode="wait">
            {selectedBooking ? (
              <motion.div
                key={selectedBooking.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                transition={{ duration: 0.2 }}
              >
                <Card className="border-slate-100 shadow-sm overflow-hidden h-full">
                  <CardHeader className="border-b border-slate-100">
                    <div className="flex flex-wrap items-center justify-between gap-4">
                      <div>
                        <CardTitle className="text-xl font-bold text-slate-900">Request Details</CardTitle>
                        <CardDescription>Submission from {selectedBooking.user.username}</CardDescription>
                      </div>
                      <div className="flex items-center gap-2">
                        <Button 
                          variant="outline" 
                          size="sm"
                          className="text-red-600 border-red-100 hover:bg-red-50 hover:text-red-700 hover:border-red-200"
                          onClick={() => {
                            reject(selectedBooking.id);
                            setSelectedBookingId(null);
                          }}
                          disabled={isRejecting}
                          data-testid="button-deny-request"
                        >
                          <X className="w-4 h-4 mr-2" /> Deny
                        </Button>
                        <Button 
                          size="sm"
                          className="bg-green-600 hover:bg-green-700 text-white"
                          onClick={() => {
                            approve(selectedBooking.id);
                            setSelectedBookingId(null);
                          }}
                          disabled={isApproving}
                          data-testid="button-approve-request"
                        >
                          <Check className="w-4 h-4 mr-2" /> Approve
                        </Button>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent className="p-6 space-y-6">
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                      <div className="space-y-1">
                        <p className="text-xs font-medium text-slate-400 uppercase tracking-wider">Flight</p>
                        <p className="text-sm font-bold text-slate-700">{selectedBooking.flight.flightNumber}</p>
                      </div>
                      <div className="space-y-1">
                        <p className="text-xs font-medium text-slate-400 uppercase tracking-wider">Route</p>
                        <p className="text-sm font-bold text-slate-700">{selectedBooking.flight.departure} → {selectedBooking.flight.arrival}</p>
                      </div>
                      <div className="space-y-1">
                        <p className="text-xs font-medium text-slate-400 uppercase tracking-wider">Pilot Level</p>
                        <p className="text-sm font-bold text-slate-700">Lvl {selectedBooking.user.level}</p>
                      </div>
                      <div className="space-y-1">
                        <p className="text-xs font-medium text-slate-400 uppercase tracking-wider">Submitted</p>
                        <p className="text-sm font-bold text-slate-700">{format(new Date(selectedBooking.createdAt!), 'MMM d, HH:mm')}</p>
                      </div>
                    </div>

                    <div className="space-y-3">
                      <div className="flex items-center justify-between">
                        <p className="text-sm font-semibold text-slate-700">Submission Proof</p>
                        {selectedBooking.proofUrl && (
                          <Button 
                            variant="ghost" 
                            size="sm" 
                            className="text-primary h-auto p-0"
                            onClick={() => setSelectedProof(selectedBooking.proofUrl)}
                          >
                            <Eye className="w-3 h-3 mr-1" /> Full Screen
                          </Button>
                        )}
                      </div>
                      {selectedBooking.proofUrl ? (
                        <div className="relative aspect-video bg-slate-100 rounded-xl overflow-hidden border border-slate-200 group cursor-zoom-in" onClick={() => setSelectedProof(selectedBooking.proofUrl)}>
                          <img 
                            src={selectedBooking.proofUrl} 
                            alt="Flight Proof" 
                            className="w-full h-full object-contain transition-transform group-hover:scale-105" 
                          />
                        </div>
                      ) : (
                        <div className="aspect-video bg-slate-50 rounded-xl border-2 border-dashed border-slate-200 flex flex-col items-center justify-center text-slate-400">
                          <AlertCircle className="w-8 h-8 mb-2 opacity-50" />
                          <p className="text-sm font-medium">No proof provided</p>
                        </div>
                      )}
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ) : (
              <div className="h-full flex flex-col items-center justify-center p-12 bg-white rounded-2xl border border-dashed border-slate-200 text-slate-400 min-h-[400px]">
                <div className="w-16 h-16 bg-slate-50 rounded-full flex items-center justify-center mb-4">
                  <CheckSquare className="w-8 h-8 opacity-20" />
                </div>
                <h3 className="text-lg font-semibold text-slate-900">Select a Request</h3>
                <p className="text-sm max-w-xs text-center mt-1">Select a pilot submission from the left to review the flight details and proof.</p>
              </div>
            )}
          </AnimatePresence>
        </div>
      </div>

      <Dialog open={!!selectedProof} onOpenChange={() => setSelectedProof(null)}>
        <DialogContent className="max-w-4xl">
          <DialogHeader>
            <DialogTitle>Flight Proof Verification</DialogTitle>
          </DialogHeader>
          {selectedProof && (
            <div className="relative aspect-video bg-slate-100 rounded-lg overflow-hidden border border-slate-200">
              <img 
                src={selectedProof} 
                alt="Flight Proof Full" 
                className="w-full h-full object-contain" 
              />
            </div>
          )}
          <DialogFooter>
            <Button onClick={() => setSelectedProof(null)}>Close View</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}