import { useUsers } from "@/hooks/use-users";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Trophy, Medal, Crown, AlertTriangle, Zap, Trash2 } from "lucide-react";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

export default function Pilots() {
  const { data: users, isLoading } = useUsers();
  const { toast } = useToast();

  const updateStats = async (id: number, stats: any) => {
    try {
      await apiRequest("POST", `/api/users/${id}/stats`, stats);
      queryClient.invalidateQueries({ queryKey: ["/api/users"] });
      toast({ title: "Stats updated" });
    } catch (e) {
      toast({ title: "Failed to update stats", variant: "destructive" });
    }
  };

  const clearBookings = async (id: number) => {
    try {
      await apiRequest("DELETE", `/api/users/${id}/bookings`);
      toast({ title: "Bookings cleared" });
    } catch (e) {
      toast({ title: "Failed to clear bookings", variant: "destructive" });
    }
  };

  if (isLoading) return <div className="p-8 text-center text-slate-500">Loading pilots...</div>;

  const sortedUsers = [...(users || [])].sort((a, b) => b.level - a.level || b.xp - a.xp);

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl font-display font-bold text-slate-900">Pilot Roster</h1>
        <p className="text-slate-500 mt-2">Manage personnel and view pilot rankings.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {sortedUsers.map((user, index) => (
          <motion.div
            key={user.id}
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: index * 0.05 }}
            className="bg-white rounded-2xl p-6 shadow-sm border border-slate-100 flex flex-col relative overflow-hidden group hover:shadow-md transition-all duration-300"
          >
            <div className="flex items-center space-x-4 mb-4">
              {index < 3 && (
                <div className="absolute -right-6 -top-6 w-20 h-20 bg-gradient-to-br from-yellow-100 to-amber-50 rounded-full flex items-center justify-center opacity-50 group-hover:opacity-100 transition-opacity">
                  <Crown className={`w-8 h-8 relative top-3 right-3 ${
                    index === 0 ? "text-yellow-500" : 
                    index === 1 ? "text-slate-400" : 
                    "text-amber-700"
                  }`} />
                </div>
              )}
              
              <Avatar className="h-16 w-16 border-4 border-slate-50 shadow-sm">
                <AvatarFallback className="bg-primary text-white text-xl font-bold">
                  {user.username.substring(0, 2).toUpperCase()}
                </AvatarFallback>
              </Avatar>
              
              <div className="flex-1 z-10">
                <h3 className="text-lg font-bold text-slate-900">{user.username}</h3>
                <div className="flex items-center mt-1 space-x-2">
                  <span className="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-blue-50 text-blue-700 border border-blue-100">
                    Level {user.level}
                  </span>
                  {user.warnings > 0 && (
                    <span className="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-red-50 text-red-700 border border-red-100">
                      {user.warnings} Warns
                    </span>
                  )}
                </div>
              </div>
            </div>

            <div className="space-y-4">
              <div>
                <div className="w-full bg-slate-100 rounded-full h-1.5 overflow-hidden">
                  <div 
                    className="bg-primary h-full rounded-full" 
                    style={{ width: `${Math.min((user.xp / (user.level * 1000)) * 100, 100)}%` }} 
                  />
                </div>
                <p className="text-[10px] text-slate-400 mt-1 text-right">{user.xp} XP</p>
              </div>

              <div className="flex flex-wrap gap-2 pt-2 border-t border-slate-50">
                <Button 
                  size="sm" 
                  variant="outline" 
                  className="h-8 text-xs text-amber-600 border-amber-100 hover:bg-amber-50 hover:text-amber-700 hover:border-amber-200"
                  onClick={() => updateStats(user.id, { warnings: user.warnings + 1 })}
                >
                  <AlertTriangle className="w-3 h-3 mr-1" /> Warn
                </Button>
                <Button 
                  size="sm" 
                  variant="outline" 
                  className="h-8 text-xs text-blue-600 border-blue-100 hover:bg-blue-50 hover:text-blue-700 hover:border-blue-200"
                  onClick={() => updateStats(user.id, { xp: user.xp + 100 })}
                >
                  <Zap className="w-3 h-3 mr-1" /> +100 XP
                </Button>
                <Button 
                  size="sm" 
                  variant="outline" 
                  className="h-8 text-xs text-red-600 border-red-100 hover:bg-red-50 hover:text-red-700 hover:border-red-200"
                  onClick={() => clearBookings(user.id)}
                >
                  <Trash2 className="w-3 h-3 mr-1" /> Clear Flights
                </Button>
              </div>
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  );
}
