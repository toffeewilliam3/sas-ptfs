import { StatCard } from "@/components/ui/StatCard";
import { useBookings } from "@/hooks/use-bookings";
import { useFlights } from "@/hooks/use-flights";
import { useUsers } from "@/hooks/use-users";
import { Plane, Users, CheckSquare, Clock, ShieldCheck, ArrowUpRight } from "lucide-react";
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer 
} from 'recharts';
import { motion } from "framer-motion";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";

export default function Dashboard() {
  const { data: bookings } = useBookings();
  const { data: flights } = useFlights();
  const { data: users } = useUsers();

  const stats = [
    { 
      title: "Active Pilots", 
      value: users?.length || 0, 
      icon: Users,
      trend: "+12%",
      trendUp: true
    },
    { 
      title: "Total Flights", 
      value: flights?.length || 0, 
      icon: Plane,
      trend: "+4 new",
      trendUp: true
    },
    { 
      title: "Pending Reviews", 
      value: bookings?.filter(b => b.status === "submitted").length || 0, 
      icon: CheckSquare,
      trend: "Needs attention",
      trendUp: false
    },
    { 
      title: "Total Hours", 
      value: "1,248", 
      icon: Clock,
      trend: "+8%",
      trendUp: true
    },
  ];

  // Dummy data for the chart
  const data = [
    { name: 'Mon', flights: 12 },
    { name: 'Tue', flights: 19 },
    { name: 'Wed', flights: 15 },
    { name: 'Thu', flights: 22 },
    { name: 'Fri', flights: 28 },
    { name: 'Sat', flights: 35 },
    { name: 'Sun', flights: 30 },
  ];

  const container = {
    hidden: { opacity: 0 },
    show: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  };

  const item = {
    hidden: { opacity: 0, y: 20 },
    show: { opacity: 1, y: 0 }
  };

  return (
    <div className="space-y-8">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-display font-bold text-slate-900 tracking-tight">System Overview</h1>
          <p className="text-slate-500 mt-2">SAS Scandinavian Airlines • PTFS Operations</p>
        </div>
        <div className="flex gap-3">
          <Link href="/admin">
            <Button className="bg-slate-900 hover:bg-slate-800 text-white shadow-sm">
              <ShieldCheck className="w-4 h-4 mr-2" />
              Admin Hub
            </Button>
          </Link>
          <Link href="/flights">
            <Button variant="outline" className="shadow-sm">
              View Network
              <ArrowUpRight className="w-4 h-4 ml-2" />
            </Button>
          </Link>
        </div>
      </div>

      <motion.div 
        variants={container}
        initial="hidden"
        animate="show"
        className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6"
      >
        {stats.map((stat, i) => (
          <motion.div key={i} variants={item}>
            <StatCard {...stat} />
          </motion.div>
        ))}
      </motion.div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="lg:col-span-2 bg-white rounded-2xl shadow-sm border border-slate-100 p-6"
        >
          <h3 className="text-lg font-bold font-display mb-6">Weekly Flight Activity</h3>
          <div className="h-[300px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={data}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e2e8f0" />
                <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{ fill: '#64748b' }} dy={10} />
                <YAxis axisLine={false} tickLine={false} tick={{ fill: '#64748b' }} />
                <Tooltip 
                  cursor={{ fill: '#f1f5f9' }}
                  contentStyle={{ borderRadius: '8px', border: 'none', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)' }}
                />
                <Bar 
                  dataKey="flights" 
                  fill="hsl(var(--primary))" 
                  radius={[4, 4, 0, 0]} 
                  barSize={30}
                />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </motion.div>

        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
          className="bg-white rounded-2xl shadow-sm border border-slate-100 p-6"
        >
          <h3 className="text-lg font-bold font-display mb-6">Recent Bookings</h3>
          <div className="space-y-6">
            {(bookings || []).slice(0, 5).map((booking) => (
              <div key={booking.id} className="flex items-center justify-between pb-4 border-b border-slate-50 last:border-0 last:pb-0">
                <div className="flex items-center space-x-3">
                  <div className="h-10 w-10 rounded-full bg-slate-100 flex items-center justify-center text-slate-500 font-bold text-xs">
                    {booking.flight.flightNumber}
                  </div>
                  <div>
                    <p className="text-sm font-medium text-slate-900">{booking.user.username}</p>
                    <p className="text-xs text-slate-500">{new Date(booking.createdAt!).toLocaleDateString()}</p>
                  </div>
                </div>
                <span className={`px-2.5 py-0.5 rounded-full text-xs font-medium ${
                  booking.status === 'approved' ? 'bg-green-100 text-green-700' :
                  booking.status === 'submitted' ? 'bg-yellow-100 text-yellow-700' :
                  'bg-slate-100 text-slate-700'
                }`}>
                  {booking.status}
                </span>
              </div>
            ))}
            {(!bookings || bookings.length === 0) && (
              <p className="text-slate-500 text-sm text-center py-4">No recent bookings found.</p>
            )}
          </div>
        </motion.div>
      </div>
    </div>
  );
}
