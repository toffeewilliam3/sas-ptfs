import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { useBookings, useApproveBooking, useRejectBooking } from "@/hooks/use-bookings";
import { Check, X, Eye, Clock, Calendar } from "lucide-react";
import { useState } from "react";
import { format } from "date-fns";
import { motion, AnimatePresence } from "framer-motion";

export default function Bookings() {
  const { data: bookings, isLoading } = useBookings();
  const { mutate: approve, isPending: isApproving } = useApproveBooking();
  const { mutate: reject, isPending: isRejecting } = useRejectBooking();
  
  const [selectedProof, setSelectedProof] = useState<string | null>(null);

  if (isLoading) return <div className="p-8 text-center text-slate-500">Loading bookings...</div>;

  // Sort: Submitted first, then by date
  const sortedBookings = [...(bookings || [])].sort((a, b) => {
    if (a.status === 'submitted' && b.status !== 'submitted') return -1;
    if (a.status !== 'submitted' && b.status === 'submitted') return 1;
    return new Date(b.createdAt!).getTime() - new Date(a.createdAt!).getTime();
  });

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl font-display font-bold text-slate-900">Bookings & Reviews</h1>
        <p className="text-slate-500 mt-2">Review flight submissions and track ongoing flights.</p>
      </div>

      <div className="bg-white rounded-2xl shadow-sm border border-slate-100 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-slate-100">
            <thead className="bg-slate-50/50">
              <tr>
                <th scope="col" className="px-6 py-4 text-left text-xs font-semibold text-slate-500 uppercase tracking-wider">Pilot</th>
                <th scope="col" className="px-6 py-4 text-left text-xs font-semibold text-slate-500 uppercase tracking-wider">Flight</th>
                <th scope="col" className="px-6 py-4 text-left text-xs font-semibold text-slate-500 uppercase tracking-wider">Route</th>
                <th scope="col" className="px-6 py-4 text-left text-xs font-semibold text-slate-500 uppercase tracking-wider">Date</th>
                <th scope="col" className="px-6 py-4 text-left text-xs font-semibold text-slate-500 uppercase tracking-wider">Status</th>
                <th scope="col" className="px-6 py-4 text-right text-xs font-semibold text-slate-500 uppercase tracking-wider">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 bg-white">
              <AnimatePresence>
                {sortedBookings.map((booking) => (
                  <motion.tr 
                    key={booking.id}
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    exit={{ opacity: 0 }}
                    layout
                    className="hover:bg-slate-50/50 transition-colors"
                  >
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex items-center">
                        <div className="h-8 w-8 rounded-full bg-primary/10 flex items-center justify-center text-primary font-bold text-xs">
                          {booking.user.username.substring(0, 2).toUpperCase()}
                        </div>
                        <div className="ml-4">
                          <div className="text-sm font-medium text-slate-900">{booking.user.username}</div>
                          <div className="text-xs text-slate-500">Lvl {booking.user.level}</div>
                        </div>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className="text-sm font-bold text-slate-700 bg-slate-100 px-2 py-1 rounded">
                        {booking.flight.flightNumber}
                      </span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex items-center text-sm text-slate-600">
                        <span className="font-medium">{booking.flight.departure}</span>
                        <span className="mx-2 text-slate-300">→</span>
                        <span className="font-medium">{booking.flight.arrival}</span>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex flex-col text-sm text-slate-500">
                        <span className="flex items-center"><Calendar className="w-3 h-3 mr-1" /> {format(new Date(booking.createdAt!), 'MMM d, yyyy')}</span>
                        <span className="flex items-center mt-1 text-xs"><Clock className="w-3 h-3 mr-1" /> {format(new Date(booking.createdAt!), 'HH:mm')}</span>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium capitalize ${
                        booking.status === 'approved' ? 'bg-green-100 text-green-700' :
                        booking.status === 'rejected' ? 'bg-red-100 text-red-700' :
                        booking.status === 'submitted' ? 'bg-amber-100 text-amber-700 animate-pulse' :
                        'bg-slate-100 text-slate-700'
                      }`}>
                        {booking.status}
                      </span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                      {booking.status === 'submitted' ? (
                        <div className="flex items-center justify-end space-x-2">
                          {booking.proofUrl && (
                            <Button 
                              variant="ghost" 
                              size="sm" 
                              onClick={() => setSelectedProof(booking.proofUrl)}
                              className="text-slate-500 hover:text-primary hover:bg-primary/5"
                            >
                              <Eye className="w-4 h-4" />
                            </Button>
                          )}
                          <Button 
                            size="sm" 
                            variant="outline"
                            className="text-green-600 border-green-200 hover:bg-green-50 hover:text-green-700 hover:border-green-300"
                            onClick={() => approve(booking.id)}
                            disabled={isApproving}
                          >
                            <Check className="w-4 h-4 mr-1" /> Approve
                          </Button>
                          <Button 
                            size="sm" 
                            variant="outline"
                            className="text-red-600 border-red-200 hover:bg-red-50 hover:text-red-700 hover:border-red-300"
                            onClick={() => reject(booking.id)}
                            disabled={isRejecting}
                          >
                            <X className="w-4 h-4" />
                          </Button>
                        </div>
                      ) : (
                        <span className="text-slate-400 text-xs">-</span>
                      )}
                    </td>
                  </motion.tr>
                ))}
              </AnimatePresence>
            </tbody>
          </table>
          
          {(!bookings || bookings.length === 0) && (
            <div className="p-12 text-center">
              <p className="text-slate-500">No bookings found in the system.</p>
            </div>
          )}
        </div>
      </div>

      <Dialog open={!!selectedProof} onOpenChange={() => setSelectedProof(null)}>
        <DialogContent className="max-w-3xl">
          <DialogHeader>
            <DialogTitle>Flight Proof</DialogTitle>
            <DialogDescription>
              Verify the flight completion proof submitted by the pilot.
            </DialogDescription>
          </DialogHeader>
          {selectedProof && (
            <div className="relative aspect-video bg-slate-100 rounded-lg overflow-hidden border border-slate-200">
              <img 
                src={selectedProof} 
                alt="Flight Proof" 
                className="w-full h-full object-contain" 
              />
            </div>
          )}
          <DialogFooter>
            <Button onClick={() => setSelectedProof(null)}>Close</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
