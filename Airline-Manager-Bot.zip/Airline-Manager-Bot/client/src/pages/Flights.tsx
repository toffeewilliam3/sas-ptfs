import { CreateFlightDialog } from "@/components/flights/CreateFlightDialog";
import { useFlights } from "@/hooks/use-flights";
import { Plane, Clock, MapPin, AlertCircle } from "lucide-react";
import { motion } from "framer-motion";

export default function Flights() {
  const { data: flights, isLoading } = useFlights();

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-[50vh]">
        <div className="animate-pulse flex flex-col items-center">
          <Plane className="h-12 w-12 text-slate-300 mb-4" />
          <p className="text-slate-400 font-medium">Loading flight routes...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-3xl font-display font-bold text-slate-900">Flight Routes</h1>
          <p className="text-slate-500 mt-2">Manage all active flight paths and schedules.</p>
        </div>
        <CreateFlightDialog />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {flights?.map((flight, index) => (
          <motion.div
            key={flight.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.05 }}
            className="group bg-white rounded-2xl shadow-sm border border-slate-100 p-6 hover:shadow-lg transition-all duration-300 hover:-translate-y-1 relative overflow-hidden"
          >
            {/* Top accent bar */}
            <div className={`absolute top-0 left-0 right-0 h-1.5 ${flight.isMandatory ? 'bg-red-500' : 'bg-blue-500'}`} />
            
            <div className="flex justify-between items-start mb-6 pt-2">
              <div>
                <span className="inline-flex items-center px-2.5 py-0.5 rounded-md text-xs font-medium bg-slate-100 text-slate-600 mb-2">
                  {flight.airline}
                </span>
                <h3 className="text-2xl font-display font-bold text-slate-900">{flight.flightNumber}</h3>
              </div>
              {flight.isMandatory && (
                <div className="flex items-center text-red-600 bg-red-50 px-2 py-1 rounded-full">
                  <AlertCircle className="w-3 h-3 mr-1" />
                  <span className="text-[10px] uppercase font-bold tracking-wider">Mandatory</span>
                </div>
              )}
            </div>

            <div className="flex items-center justify-between mb-8 relative">
              <div className="text-center w-1/3">
                <p className="text-2xl font-bold text-slate-800">{flight.departure}</p>
                <p className="text-xs text-slate-400 mt-1 uppercase tracking-wide">Departs</p>
              </div>
              
              <div className="flex-1 flex flex-col items-center px-2">
                <div className="w-full h-px bg-slate-200 relative top-3"></div>
                <Plane className="w-5 h-5 text-blue-500 transform rotate-90 bg-white z-10 p-0.5" />
                <p className="text-xs text-slate-400 mt-2">{flight.durationMinutes}m</p>
              </div>
              
              <div className="text-center w-1/3">
                <p className="text-2xl font-bold text-slate-800">{flight.arrival}</p>
                <p className="text-xs text-slate-400 mt-1 uppercase tracking-wide">Arrives</p>
              </div>
            </div>

            <div className="flex items-center justify-between pt-4 border-t border-slate-50">
              <div className="flex items-center text-slate-500 text-sm">
                <Clock className="w-4 h-4 mr-2 text-slate-400" />
                <span>{Math.floor(flight.durationMinutes / 60)}h {flight.durationMinutes % 60}m</span>
              </div>
              <div className="flex items-center text-slate-500 text-sm">
                <MapPin className="w-4 h-4 mr-2 text-slate-400" />
                <span>Direct</span>
              </div>
            </div>
          </motion.div>
        ))}

        {(!flights || flights.length === 0) && (
          <div className="col-span-full flex flex-col items-center justify-center p-12 bg-white rounded-2xl border border-dashed border-slate-200">
            <div className="h-16 w-16 bg-slate-50 rounded-full flex items-center justify-center mb-4">
              <Plane className="h-8 w-8 text-slate-300" />
            </div>
            <h3 className="text-lg font-medium text-slate-900">No flights yet</h3>
            <p className="text-slate-500 text-center max-w-sm mt-2">
              Get started by creating your first flight route using the button above.
            </p>
          </div>
        )}
      </div>
    </div>
  );
}
