import { useUsers } from "@/hooks/use-users";
import { useBookings } from "@/hooks/use-bookings";
import { useFlights } from "@/hooks/use-flights";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Bell, AlertTriangle, Zap, Trash2, MapPin, ShieldCheck, ArrowLeft } from "lucide-react";
import { useState } from "react";
import Approvals from "./Approvals";
import Flights from "./Flights";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { motion } from "framer-motion";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

export default function AdminHub() {
  const [activeTab, setActiveTab] = useState<"menu" | "approvals" | "routes">("menu");
  const { data: users } = useUsers();
  const { data: bookings } = useBookings();
  const { toast } = useToast();

  const [dialogOpen, setDialogOpen] = useState<"warn" | "level" | "remove" | null>(null);
  const [selectedUserId, setSelectedUserId] = useState<string>("");
  const [xpAmount, setXpAmount] = useState<string>("100");

  const pendingCount = (bookings || []).filter(b => b.status === "submitted").length;

  const handleAction = async (type: string) => {
    if (!selectedUserId) {
      toast({ title: "Please select a user", variant: "destructive" });
      return;
    }

    const userId = parseInt(selectedUserId);
    const user = users?.find(u => u.id === userId);

    try {
      if (type === "warn") {
        await apiRequest("POST", `/api/users/${userId}/stats`, { warnings: (user?.warnings || 0) + 1 });
        toast({ title: "User warned" });
      } else if (type === "level") {
        const amount = parseInt(xpAmount);
        await apiRequest("POST", `/api/users/${userId}/stats`, { xp: (user?.xp || 0) + amount, dmNotify: true });
        toast({ title: "XP added" });
      } else if (type === "remove") {
        await apiRequest("DELETE", `/api/users/${userId}/bookings`);
        toast({ title: "Active flight plans removed" });
      }
      queryClient.invalidateQueries({ queryKey: ["/api/users"] });
      setDialogOpen(null);
    } catch (e) {
      toast({ title: "Action failed", variant: "destructive" });
    }
  };

  const adminButtons = [
    {
      id: "warn",
      title: "Warn/Ban",
      description: "Manage pilot warnings and conduct.",
      icon: AlertTriangle,
      color: "text-amber-600",
      bg: "bg-amber-50",
      border: "border-amber-100",
    },
    {
      id: "approvals",
      title: "Approvals",
      description: "Review pending flight submissions.",
      icon: Bell,
      color: "text-blue-600",
      bg: "bg-blue-50",
      border: "border-blue-100",
      badge: pendingCount > 0 ? pendingCount : null,
    },
    {
      id: "level",
      title: "Level/XP",
      description: "Manually adjust pilot progression.",
      icon: Zap,
      color: "text-purple-600",
      bg: "bg-purple-50",
      border: "border-purple-100",
    },
    {
      id: "remove",
      title: "Remove Flight Plan",
      description: "Cancel active flight bookings for pilots.",
      icon: Trash2,
      color: "text-red-600",
      bg: "bg-red-50",
      border: "border-red-100",
    },
    {
      id: "routes",
      title: "Flight Routes",
      description: "Manage airline routes and schedules.",
      icon: MapPin,
      color: "text-emerald-600",
      bg: "bg-emerald-50",
      border: "border-emerald-100",
    },
  ];

  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-display font-bold text-slate-900 flex items-center">
            <ShieldCheck className="w-8 h-8 mr-3 text-primary" />
            Admin Hub
          </h1>
          <p className="text-slate-500 mt-2">Central control for airline operations.</p>
        </div>
        {activeTab !== "menu" && (
          <Button variant="outline" onClick={() => setActiveTab("menu")} className="group">
            <ArrowLeft className="w-4 h-4 mr-2 group-hover:-translate-x-1 transition-transform" />
            Back to Menu
          </Button>
        )}
      </div>

      {activeTab === "menu" ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {adminButtons.map((btn) => (
            <motion.div
              key={btn.id}
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              onClick={() => {
                if (btn.id === "approvals") setActiveTab("approvals");
                else if (btn.id === "routes") setActiveTab("routes");
                else setDialogOpen(btn.id as any);
              }}
              className="cursor-pointer group"
            >
              <Card className={`border-2 ${btn.border} hover:shadow-lg transition-all duration-300 h-full`}>
                <CardContent className="p-6 flex flex-col items-center text-center space-y-4">
                  <div className={`h-16 w-16 ${btn.bg} ${btn.color} rounded-2xl flex items-center justify-center shrink-0 group-hover:scale-110 transition-transform`}>
                    <btn.icon className="h-8 w-8" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-center space-x-2">
                      <CardTitle className="text-xl font-bold text-slate-900">{btn.title}</CardTitle>
                      {btn.badge && (
                        <span className="bg-red-500 text-white text-xs font-bold px-2 py-0.5 rounded-full animate-pulse">
                          {btn.badge}
                        </span>
                      )}
                    </div>
                    <CardDescription className="mt-2 line-clamp-2 text-sm">{btn.description}</CardDescription>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
      ) : (
        <div className="bg-white rounded-2xl p-6 shadow-sm border border-slate-100">
          {activeTab === "approvals" && <Approvals />}
          {activeTab === "routes" && <Flights />}
        </div>
      )}

      <Dialog open={!!dialogOpen} onOpenChange={() => setDialogOpen(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>
              {dialogOpen === "warn" && "Issue Warning"}
              {dialogOpen === "level" && "Adjust Level/XP"}
              {dialogOpen === "remove" && "Remove Flight Plan"}
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label>Select Pilot</Label>
              <Select onValueChange={setSelectedUserId} value={selectedUserId}>
                <SelectTrigger>
                  <SelectValue placeholder="Choose a pilot..." />
                </SelectTrigger>
                <SelectContent>
                  {users?.map(user => (
                    <SelectItem key={user.id} value={user.id.toString()}>
                      {user.username} (Lvl {user.level})
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            {dialogOpen === "level" && (
              <div className="space-y-2">
                <Label>XP Amount</Label>
                <Input 
                  type="number" 
                  value={xpAmount} 
                  onChange={(e) => setXpAmount(e.target.value)} 
                />
              </div>
            )}
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(null)}>Cancel</Button>
            <Button 
              className={dialogOpen === "remove" ? "bg-red-600 hover:bg-red-700 text-white" : ""}
              onClick={() => handleAction(dialogOpen!)}
            >
              Confirm Action
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}