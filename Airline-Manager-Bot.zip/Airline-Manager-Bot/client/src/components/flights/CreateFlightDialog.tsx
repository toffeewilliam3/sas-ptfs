import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { useCreateFlight } from "@/hooks/use-flights";
import { Plus, Loader2 } from "lucide-react";
import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { insertFlightSchema } from "@shared/schema";

// Form schema with refinement for numeric strings
const formSchema = insertFlightSchema.extend({
  durationMinutes: z.string().transform((val) => parseInt(val, 10)),
});

type FormData = z.input<typeof formSchema>;

export function CreateFlightDialog() {
  const [open, setOpen] = useState(false);
  const { mutate, isPending } = useCreateFlight();
  
  const { register, handleSubmit, reset, formState: { errors } } = useForm<FormData>({
    resolver: zodResolver(insertFlightSchema),
    defaultValues: {
      isMandatory: false,
    }
  });

  const onSubmit = (data: FormData) => {
    mutate(data as any, {
      onSuccess: () => {
        setOpen(false);
        reset();
      },
    });
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button className="bg-primary hover:bg-primary/90 text-white shadow-lg shadow-primary/25">
          <Plus className="mr-2 h-4 w-4" /> Add Flight Route
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-[500px] rounded-2xl">
        <DialogHeader>
          <DialogTitle className="font-display text-2xl">Create New Flight Route</DialogTitle>
          <DialogDescription>
            Add a new scheduled flight to the database.
          </DialogDescription>
        </DialogHeader>
        
        <form onSubmit={handleSubmit(onSubmit)} className="space-y-6 py-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="flightNumber">Flight Number</Label>
              <Input
                id="flightNumber"
                placeholder="SAS901"
                {...register("flightNumber")}
                className="rounded-xl border-slate-200 focus:ring-primary/20"
              />
              {errors.flightNumber && <p className="text-xs text-destructive">{errors.flightNumber.message}</p>}
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="airline">Airline</Label>
              <Input
                id="airline"
                placeholder="SAS"
                {...register("airline")}
                className="rounded-xl border-slate-200 focus:ring-primary/20"
              />
              {errors.airline && <p className="text-xs text-destructive">{errors.airline.message}</p>}
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="departure">Departure (ICAO)</Label>
              <Input
                id="departure"
                placeholder="ESSA"
                {...register("departure")}
                className="rounded-xl border-slate-200 focus:ring-primary/20"
              />
              {errors.departure && <p className="text-xs text-destructive">{errors.departure.message}</p>}
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="arrival">Arrival (ICAO)</Label>
              <Input
                id="arrival"
                placeholder="EKCH"
                {...register("arrival")}
                className="rounded-xl border-slate-200 focus:ring-primary/20"
              />
              {errors.arrival && <p className="text-xs text-destructive">{errors.arrival.message}</p>}
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="durationMinutes">Duration (Minutes)</Label>
            <Input
              id="durationMinutes"
              type="number"
              placeholder="60"
              {...register("durationMinutes", { valueAsNumber: true })}
              className="rounded-xl border-slate-200 focus:ring-primary/20"
            />
            {errors.durationMinutes && <p className="text-xs text-destructive">{errors.durationMinutes.message}</p>}
          </div>

          <div className="flex items-center space-x-2 bg-slate-50 p-4 rounded-xl">
            <Switch id="isMandatory" {...register("isMandatory")} />
            <Label htmlFor="isMandatory" className="cursor-pointer font-medium">Mark as Mandatory Flight</Label>
          </div>

          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => setOpen(false)} className="rounded-xl">
              Cancel
            </Button>
            <Button 
              type="submit" 
              className="rounded-xl bg-primary hover:bg-primary/90"
              disabled={isPending}
            >
              {isPending ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" /> Creating...
                </>
              ) : (
                "Create Route"
              )}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
