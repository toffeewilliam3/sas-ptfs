import { Link, useLocation } from "wouter";
import { cn } from "@/lib/utils";
import { Plane, Users, CheckSquare, LayoutDashboard, Settings, Bell } from "lucide-react";

const navigation = [
  { name: 'Dashboard', href: '/', icon: LayoutDashboard },
  { name: 'Flights', href: '/flights', icon: Plane },
  { name: 'Bookings', href: '/bookings', icon: CheckSquare },
  { name: 'Pilots', href: '/pilots', icon: Users },
  { name: 'Admin Hub', href: '/admin', icon: Settings },
];

export function Sidebar() {
  const [location] = useLocation();

  return (
    <div className="hidden md:flex md:w-64 md:flex-col fixed inset-y-0 z-50">
      {/* Sidebar component, swap this element with another sidebar if you like */}
      <div className="flex flex-col flex-grow bg-slate-900 pt-5 pb-4 overflow-y-auto">
        <div className="flex items-center flex-shrink-0 px-4 mb-8">
          <div className="h-10 w-10 bg-gradient-to-tr from-blue-500 to-cyan-400 rounded-lg flex items-center justify-center mr-3 shadow-lg shadow-blue-500/20">
            <Plane className="h-6 w-6 text-white transform -rotate-45" />
          </div>
          <div className="flex flex-col">
            <span className="font-display font-bold text-white text-lg tracking-wide">SAS PTFS</span>
            <span className="text-xs text-slate-400 uppercase tracking-wider font-medium">Admin Console</span>
          </div>
        </div>
        <div className="mt-5 flex-1 flex flex-col">
          <nav className="flex-1 px-2 space-y-1">
            {navigation.map((item) => {
              const isActive = location === item.href;
              return (
                <Link
                  key={item.name}
                  href={item.href}
                  className={cn(
                    isActive
                      ? 'bg-blue-600/10 text-white border-l-4 border-blue-500'
                      : 'text-slate-400 hover:bg-slate-800 hover:text-white border-l-4 border-transparent',
                    'group flex items-center px-3 py-3 text-sm font-medium transition-all duration-200 ease-in-out'
                  )}
                >
                  <item.icon
                    className={cn(
                      isActive ? 'text-blue-400' : 'text-slate-500 group-hover:text-slate-300',
                      'mr-3 flex-shrink-0 h-5 w-5 transition-colors duration-200'
                    )}
                    aria-hidden="true"
                  />
                  {item.name}
                </Link>
              );
            })}
          </nav>
        </div>
        <div className="flex-shrink-0 flex border-t border-slate-800 p-4">
          <div className="flex items-center">
            <div>
              <div className="h-9 w-9 rounded-full bg-slate-700 flex items-center justify-center text-white font-medium">
                AD
              </div>
            </div>
            <div className="ml-3">
              <p className="text-sm font-medium text-white">Administrator</p>
              <p className="text-xs font-medium text-slate-500">System Manager</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
