## Packages
framer-motion | For smooth page transitions and micro-interactions
recharts | For visualizing user progress and flight statistics
clsx | For conditional class merging
tailwind-merge | For conditional class merging
date-fns | For formatting dates and times nicely
lucide-react | For beautiful icons (already in base but good to confirm)

## Notes
Tailwind Config - extend fontFamily:
fontFamily: {
  display: ["var(--font-display)"],
  body: ["var(--font-body)"],
}
