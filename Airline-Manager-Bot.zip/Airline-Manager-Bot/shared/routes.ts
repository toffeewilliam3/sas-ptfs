import { z } from 'zod';
import { insertFlightSchema, insertBookingSchema, insertAircraftSchema, bookings, flights, users, aircraft } from './schema';

export const errorSchemas = {
  validation: z.object({
    message: z.string(),
    field: z.string().optional(),
  }),
  notFound: z.object({
    message: z.string(),
  }),
  internal: z.object({
    message: z.string(),
  }),
};

export const api = {
  aircraft: {
    list: {
      method: 'GET' as const,
      path: '/api/aircraft',
      responses: {
        200: z.array(z.custom<typeof aircraft.$inferSelect>()),
      },
    },
    create: {
      method: 'POST' as const,
      path: '/api/aircraft',
      input: insertAircraftSchema,
      responses: {
        201: z.custom<typeof aircraft.$inferSelect>(),
        400: errorSchemas.validation,
      },
    },
  },
  flights: {
    list: {
      method: 'GET' as const,
      path: '/api/flights',
      responses: {
        200: z.array(z.custom<typeof flights.$inferSelect & { aircraft: typeof aircraft.$inferSelect | null }>()),
      },
    },
    create: {
      method: 'POST' as const,
      path: '/api/flights',
      input: insertFlightSchema,
      responses: {
        201: z.custom<typeof flights.$inferSelect>(),
        400: errorSchemas.validation,
      },
    },
    delete: {
      method: 'DELETE' as const,
      path: '/api/flights/:id',
      responses: {
        204: z.void(),
        404: errorSchemas.notFound,
      },
    },
  },
  bookings: {
    list: {
      method: 'GET' as const,
      path: '/api/bookings',
      responses: {
        200: z.array(z.custom<typeof bookings.$inferSelect & { user: typeof users.$inferSelect; flight: typeof flights.$inferSelect }>()),
      },
    },
    approve: {
      method: 'POST' as const,
      path: '/api/bookings/:id/approve',
      responses: {
        200: z.custom<typeof bookings.$inferSelect>(),
        404: errorSchemas.notFound,
      },
    },
    reject: {
      method: 'POST' as const,
      path: '/api/bookings/:id/reject',
      responses: {
        200: z.custom<typeof bookings.$inferSelect>(),
        404: errorSchemas.notFound,
      },
    },
  },
  users: {
    list: {
      method: 'GET' as const,
      path: '/api/users',
      responses: {
        200: z.array(z.custom<typeof users.$inferSelect>()),
      },
    },
    updateStats: {
      method: 'POST' as const,
      path: '/api/users/:id/stats',
      input: z.object({
        level: z.number().optional(),
        xp: z.number().optional(),
        warnings: z.number().optional(),
      }),
      responses: {
        200: z.custom<typeof users.$inferSelect>(),
        404: errorSchemas.notFound,
      },
    },
    makeMeAdmin: {
      method: 'POST' as const,
      path: '/api/users/make-me-admin',
      input: z.object({ discordId: z.string() }),
      responses: {
        200: z.object({ success: z.boolean() }),
        404: errorSchemas.notFound,
      },
    },
  }
};

export function buildUrl(path: string, params?: Record<string, string | number>): string {
  let url = path;
  if (params) {
    Object.entries(params).forEach(([key, value]) => {
      if (url.includes(`:${key}`)) {
        url = url.replace(`:${key}`, String(value));
      }
    });
  }
  return url;
}
