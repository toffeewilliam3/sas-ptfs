import { pgTable, text, serial, integer, boolean, timestamp, varchar } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";
import { relations } from "drizzle-orm";

// === TABLE DEFINITIONS ===

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  discordId: varchar("discord_id").notNull().unique(),
  username: text("username").notNull(),
  level: integer("level").default(1).notNull(),
  xp: integer("xp").default(0).notNull(),
  warnings: integer("warnings").default(0).notNull(),
  isAdmin: boolean("is_admin").default(false).notNull(),
});

export const aircraft = pgTable("aircraft", {
  id: serial("id").primaryKey(),
  model: text("model").notNull(), // e.g. "a320", "a330"
  displayName: text("display_name").notNull(),
});

export const flights = pgTable("flights", {
  id: serial("id").primaryKey(),
  flightNumber: text("flight_number").notNull(),
  departure: text("departure").notNull(),
  arrival: text("arrival").notNull(),
  airline: text("airline").notNull(), // SAS, etc.
  durationMinutes: integer("duration_minutes").notNull(),
  isMandatory: boolean("is_mandatory").default(false).notNull(),
  aircraftId: integer("aircraft_id").references(() => aircraft.id),
});

export const bookings = pgTable("bookings", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id).notNull(),
  flightId: integer("flight_id").references(() => flights.id).notNull(),
  status: text("status", { enum: ["booked", "flying", "submitted", "approved", "rejected", "skipped"] }).default("booked").notNull(),
  startTime: timestamp("start_time"),
  endTime: timestamp("end_time"),
  proofUrl: text("proof_url"),
  adminComment: text("admin_comment"),
  skipReason: text("skip_reason"),
  createdAt: timestamp("created_at").defaultNow(),
});

// === RELATIONS ===

export const usersRelations = relations(users, ({ many }) => ({
  bookings: many(bookings),
}));

export const aircraftRelations = relations(aircraft, ({ many }) => ({
  flights: many(flights),
}));

export const flightsRelations = relations(flights, ({ one, many }) => ({
  aircraft: one(aircraft, {
    fields: [flights.aircraftId],
    references: [aircraft.id],
  }),
  bookings: many(bookings),
}));

export const bookingsRelations = relations(bookings, ({ one }) => ({
  user: one(users, {
    fields: [bookings.userId],
    references: [users.id],
  }),
  flight: one(flights, {
    fields: [bookings.flightId],
    references: [flights.id],
  }),
}));

// === SCHEMAS ===

export const insertUserSchema = createInsertSchema(users).omit({ id: true });
export const insertAircraftSchema = createInsertSchema(aircraft).omit({ id: true });
export const insertFlightSchema = createInsertSchema(flights).omit({ id: true });
export const insertBookingSchema = createInsertSchema(bookings).omit({ id: true, createdAt: true });

// === TYPES ===

export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;

export type Aircraft = typeof aircraft.$inferSelect;
export type InsertAircraft = z.infer<typeof insertAircraftSchema>;

export type Flight = typeof flights.$inferSelect;
export type InsertFlight = z.infer<typeof insertFlightSchema>;

export type Booking = typeof bookings.$inferSelect;
export type InsertBooking = z.infer<typeof insertBookingSchema>;
