# SAS PTFS Admin Console

## Overview

This is a full-stack admin console for managing a Scandinavian Airlines (SAS) virtual airline operation within PTFS (Pilot Training Flight Simulator on Roblox). The application allows administrators to manage flight routes, review pilot bookings, track pilot progression, and integrate with Discord for bot-based interactions.

The system enables pilots to book flights via Discord, complete them in-simulator, submit proof of completion, and receive XP/level rewards upon admin approval.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Routing**: Wouter (lightweight client-side routing)
- **State Management**: TanStack React Query for server state
- **Styling**: Tailwind CSS with shadcn/ui component library
- **Animations**: Framer Motion for page transitions and micro-interactions
- **Charts**: Recharts for data visualization on the dashboard
- **Build Tool**: Vite with hot module replacement

The frontend follows a pages-based structure with reusable components. Custom hooks in `client/src/hooks/` encapsulate API calls and business logic. The UI uses a Scandinavian airline-inspired theme with navy blues and clean whites.

### Backend Architecture
- **Framework**: Express.js running on Node.js
- **Language**: TypeScript with ESM modules
- **API Design**: RESTful endpoints defined in `shared/routes.ts` with Zod validation
- **Database ORM**: Drizzle ORM with PostgreSQL
- **Bot Integration**: Discord.js for slash commands and user interactions

The server uses a shared schema approach where database models and API contracts live in `shared/` for type-safety across the stack. The `storage.ts` file implements the data access layer pattern.

### Database Design
- **Users**: Discord-linked accounts with level, XP, warnings, and admin status
- **Aircraft**: Available aircraft models (A320, A330, etc.)
- **Flights**: Flight routes with departure/arrival, duration, and mandatory status
- **Bookings**: Links users to flights with status workflow (booked → flying → submitted → approved/rejected)

Relationships are defined using Drizzle relations for query convenience.

### Discord Bot Integration
The Discord bot provides:
- `/book [flight]` - Book a flight
- `/start` - Start flight timer
- `/flights` - List available flights
- `/makeadmin` - Development admin assignment

The bot uses cron scheduling for periodic tasks and manages user state through the same database.

## External Dependencies

### Database
- **PostgreSQL**: Primary data store, connection via `DATABASE_URL` environment variable
- **Drizzle Kit**: Schema migrations with `npm run db:push`

### Third-Party Services
- **Discord API**: Bot functionality requires `DISCORD_TOKEN` environment variable
- **Google Fonts**: Outfit (display) and Inter (body) typefaces

### Key npm Packages
- `discord.js` - Discord bot framework
- `drizzle-orm` / `drizzle-zod` - Database ORM with Zod integration
- `@tanstack/react-query` - Server state management
- `framer-motion` - Animation library
- `recharts` - Chart components
- `node-cron` - Scheduled tasks for the bot
- `express-session` / `connect-pg-simple` - Session management (available but not fully implemented)

### Development Tools
- `tsx` - TypeScript execution for development
- `esbuild` - Production bundling for server
- Replit-specific Vite plugins for development experience